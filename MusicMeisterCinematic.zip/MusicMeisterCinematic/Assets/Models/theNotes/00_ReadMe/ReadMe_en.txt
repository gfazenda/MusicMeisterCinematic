﻿■ Asset name
The Notes


■ At first
Thank you very much to download this asset. 
I pray this character for your game development as a good sample, or pray to be used in the actual game.
Thank you:)


■ About 3D Model
10 different notes that are set to Meccanim (generic) is included in this asset.

Note : 216 ~ 467 vertex , 320 ~ 634 Tris , 9 Joint

eighth_rest : 244 vertex , 372 Tris , 7 Joint
quater_rest : 714 vertex , 644 Tris , 9 Joint
half_rest : 273 vertex , 336 Tris , 19 Joint
whole_rest : 273 vertex , 336 Tris , 19 Joint

Treble_clef : 615 vertex , 774 Tris , 23 Joint
Bass_clef : 398 vertex , 656 Tris , 12 Joint

Not used any texture map. only with material color.


■ Animation
Includes 12 Animations.
 - Appear
 - Idle
 - LookAround
 - Jiggle
 - Happy
 - Sad
 - Attack
 - Walk
 - Run
 - Jump_00
 - Jump_01
 - Disappear


■ About Demoscene
viewer mode, you can see the model and the animation one by one.  
Interactive mode, you can check it feels like play games.

the animator controller contains two types for 2 modes.

About movement
In demoscene, while in ground, apply root motion for movement. 
but while in the air during a jump, position controled through the script to move.

Material color is configured to change at random color when switching model.


■ Support
If you have any question or comment,

E-mail : trhunter@naver.com
twitter : https://twitter.com/0z_TM

