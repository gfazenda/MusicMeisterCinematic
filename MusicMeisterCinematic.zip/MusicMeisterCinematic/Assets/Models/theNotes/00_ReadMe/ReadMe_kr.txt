﻿■ 에셋 이름
The Notes


■ 인사
본 에셋을 다운로드 해주셔서 대단히 감사합니다.
이 캐릭터가 여러분의 게임 개발에 있어서 좋은 샘플로써, 혹은 실제 게임 내에 구현되는 캐릭터로서 활용되기를 
마음속깊이 기도하고 있습니다. 잘부탁드립니다:)


■ 모델에 대해서.
본 어셋에는 Meccanim(generic)으로 설정된 10종류의 음표 모델이 들어있습니다.

음표 : 216 ~ 467 vertex , 320 ~ 634 Tris , 9 Joint

8분쉼표 : 244 vertex , 372 Tris , 7 Joint
4분쉼표 : 714 vertex , 644 Tris , 9 Joint
2분쉼표 : 273 vertex , 336 Tris , 19 Joint
온쉼표 : 273 vertex , 336 Tris , 19 Joint

높은음 자리표 : 615 vertex , 774 Tris , 23 Joint
낮은음 자리표 : 398 vertex , 656 Tris , 12 Joint

텍스쳐는 사용되지 않았습니다.


■ 애니메이션
Includes 12 Animations.
 - Appear
 - Idle
 - LookAround
 - Jiggle
 - Happy
 - Sad
 - Attack
 - Walk
 - Run
 - Jump_00
 - Jump_01
 - Disappear


■ 데모신에 대해서
데모신에는 애니메이션을 하나씩 확인할 수 있는 뷰어 모드와,
좀더 게임을 플레이하는 듯한 느낌으로 조작할 수 있는 인터랙티브모드가 있습니다.
이를 위해 애니메이터 컨트롤러 샘플도 2종류가 들어있습니다.


이동에 대해서,
지상에서는 각 애니메이션의 루트모션을 사용하여 이동합니다만,
점프시 공중에 있는동안은 스크립트 제어를 통해서 이동합니다.

모델을 교체할시에 마테리얼 컬러를 랜덤으로 변경하도록 설정하고 있습니다.


■ 서포트
궁금한점이 있을경우엔 여기로

E-mail : trhunter@naver.com
twitter : https://twitter.com/0z_TM

