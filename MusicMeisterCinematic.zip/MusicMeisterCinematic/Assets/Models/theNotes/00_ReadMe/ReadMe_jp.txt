﻿■ アセット名
The Notes


■ 初めに
当アセットをダウンロードしていただき、まことにありがとうございます。
このキャラクターがあなた方のゲーム開発において、有意義なサンプルとして、
もしくは実際ゲームに使われるキャラクターとして活躍されることを心よりお祈りしております。
今後ともよろしくお願いいたします！！:)


■ モデル詳細。
当アセットにはMeccanim(generic)設定の音符のモデル10種類が含まれています。

音符 : 216 ~ 467 vertex , 320 ~ 634 Tris , 9 Joint

八分休符 : 244 vertex , 372 Tris , 7 Joint
四分休符 : 714 vertex , 644 Tris , 9 Joint
二分休符 : 273 vertex , 336 Tris , 19 Joint
全休符 : 273 vertex , 336 Tris , 19 Joint

ト音記号 : 615 vertex , 774 Tris , 23 Joint
ヘ音記号 : 398 vertex , 656 Tris , 12 Joint

テクスチャは使われていません。


■ アニメーション
Includes 12 Animations.
 - Appear
 - Idle
 - LookAround
 - Jiggle
 - Happy
 - Sad
 - Attack
 - Walk
 - Run
 - Jump_00
 - Jump_01
 - Disappear


■ デモシーンに関して
デモシーンはモーションを一つずつ確認できるビューアモードと、
アクションゲームっぽくキー操作しながら動きを確認できるインタラクティブモードがあり、
アニメーターコントローラも2種類があります。


移動に関して、基本ルートモーションにて動いていますが、
ジャンプ制御の時はスクリプト制御で移動させています。

モデルを切り替える際にマテリアルのカラーをランダムで変更するように設定しています。

■　サポート
質問やコメントなどがありましたら、以下のところに。

E-mail : trhunter@naver.com
twitter : https://twitter.com/0z_TM

